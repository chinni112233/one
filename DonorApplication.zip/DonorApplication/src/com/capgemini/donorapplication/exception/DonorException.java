package com.capgemini.donorapplication.exception;

public class DonorException extends Exception 
{
	private static final long serialVersionUID = 1L;
	public DonorException(String message) 
	{
		
		super(message);
	}
}
