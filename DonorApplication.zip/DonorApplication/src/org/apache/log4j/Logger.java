package org.apache.log4j;

import com.capgemini.donorapplication.exception.DonorException;

public class Logger {

	public static Logger getRootLogger() {
		// TODO Auto-generated method stub
		return null;
	}

	public void error(String string, DonorException donorException) {
		// TODO Auto-generated method stub
		
	}

}
