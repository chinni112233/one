package org.apache.log4j;

public class PropertyConfigurator {

	public static void configure(String string) {
		// TODO Auto-generated method stub
		
	}

	public static void configure1(String string) {
		// TODO Auto-generated method stub
		
	}

}
