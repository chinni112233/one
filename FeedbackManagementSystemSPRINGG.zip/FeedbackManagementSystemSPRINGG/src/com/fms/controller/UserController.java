package com.fms.controller;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.fms.bean.CourseMasterBean;
import com.fms.bean.FacultySkillBean;
import com.fms.bean.FeedbackBean;
import com.fms.bean.TrainingParticiEnrollBean;
import com.fms.bean.TrainingProgramBean;
import com.fms.bean.UserBean;
import com.fms.service.IUserService;

@Controller
public class UserController {
	@Autowired
	IUserService service;

	@RequestMapping("index")
	public ModelAndView homepage(){
		UserBean bean=new UserBean();
		ModelAndView view = new ModelAndView("homepage","beankey",bean);
		return view;
	}

	@RequestMapping(value="validateUserDetails",method=RequestMethod.POST)
	public ModelAndView retrieveDetails(Model model,@ModelAttribute("beankey") @Valid UserBean userBean,BindingResult result){

		boolean value=false;
		ModelAndView view=new ModelAndView();
		value=service.retrieveDetails(userBean.getEmpId(), userBean.getPassword());
		if(value==false){
			String errorMessage="Invalid Credentials";
			view = new ModelAndView("homepage");
			view.addObject("errorMessage", errorMessage);
		}
		else{
			ArrayList<UserBean> list=service.retrieveDetail(userBean.getEmpId(), userBean.getPassword());
			String role=String.valueOf(list.get(0));
			if(role.equals("Admin")){
				view = new ModelAndView("adminHome");
			}
			else if(role.equals("Cordinator")){
				view = new ModelAndView("CordinatorHome");
			}
			else{
				/*ArrayList<TrainingParticiEnrollBean> feedbackList=service.retrieveFeedbackDetails(userBean.getEmpId());
				view = new ModelAndView("UserHome","beankey",new TrainingParticiEnrollBean());*/
				view = new ModelAndView("UserHome","beankey",new FeedbackBean());
				/*view.addObject("trainingCode",feedbackList.get(0));
				view.addObject("userId", userBean.getEmpId());*/
			}
		}
		return view;
	}

	/******************Admin Operations*********************/

	//FacultyMaintenance
	@RequestMapping(value="FacultySkillMaintenance")
	public ModelAndView viewFacultySkillMaintenance(){
		ModelAndView view = new ModelAndView("FacultySkillMaintenance");
		return view;
	}

	@RequestMapping(value="viewFaculty")
	public ModelAndView viewFaculty(){
		ModelAndView view=new ModelAndView();
		ArrayList<FacultySkillBean> list=service.retrieveFacultyDetails();
		if(list.isEmpty()){
			String errorMessage="No faculty details are available";
			view = new ModelAndView("viewFaculty");
			view.addObject("errorMessage", errorMessage);
		}
		else{
			view = new ModelAndView("viewFaculty");
			view.addObject("facultyList", list);
		}
		return view;
	}

	@RequestMapping(value="addFaculty")
	public ModelAndView addFaculty(){
		ModelAndView view=new ModelAndView("addFaculty");
		return view;
	}

	//Course Maintainence
	@RequestMapping(value="CourseMaintenance")
	public ModelAndView viewCourseMaintenance(){
		ModelAndView view = new ModelAndView("CourseMaintenance");
		return view;
	}
	
	@RequestMapping(value="about")
	public ModelAndView about(){
		ModelAndView view = new ModelAndView("about");
		return view;
	}

	@RequestMapping(value="ViewCourse")
	public ModelAndView viewCourseDetails(){
		ModelAndView view=new ModelAndView();
		ArrayList<CourseMasterBean> list=service.retrieveCourseDetails();
		if(list.isEmpty()){
			String errorMessage="No courses are available";
			view = new ModelAndView("ViewCourse");
			view.addObject("errorMessage", errorMessage);
		}
		else{
			view = new ModelAndView("ViewCourse");
			view.addObject("courseList", list);
		}
		return view;
	}

	@RequestMapping(value="AddCourse",method=RequestMethod.GET)
	public ModelAndView addCourse(){
		ModelAndView view=new ModelAndView("AddCourse","bean",new CourseMasterBean());
		return view;
	}

	@RequestMapping(value="AddCourseSuccess")
	public ModelAndView courseAddSuccess(Model model,@ModelAttribute("bean") @Valid CourseMasterBean courseMasterBean,BindingResult result){
		ModelAndView view=new ModelAndView();
		boolean value=service.addCourseDetails(courseMasterBean);
		if(value==true){
			view = new ModelAndView("AddCourseSuccess");
			model.addAttribute("id",courseMasterBean.getCourseId());
		}
		else{
			String errorMessage="Course cannot be added";
			view = new ModelAndView("AddCourse");
			view.addObject("errorMessage", errorMessage);
		}
		return view;
	}

	@RequestMapping(value="DeleteCourse",method=RequestMethod.GET)
	public ModelAndView deleteCourse(){
		ModelAndView view=new ModelAndView("DeleteCourse","bean",new CourseMasterBean());
		return view;
	}


	@RequestMapping(value="ValidateCourse")
	public ModelAndView coursedDeleteSuccess(Model model,@ModelAttribute("bean") @Valid CourseMasterBean courseMasterBean,BindingResult result){
		ModelAndView view=new ModelAndView();
		boolean value=service.validateCourse(courseMasterBean.getCourseId());
		if(value==true){
			view = new ModelAndView("DeleteCourseSuccess");
			model.addAttribute("id",courseMasterBean.getCourseId());
		}
		else{
			String errorMessage="Course with this ID is not available and hence cannot be deleted";
			view = new ModelAndView("DeleteCourse");
			view.addObject("errorMessage", errorMessage);
		}
		return view;
	}

	//ViewFeedback Report
	@RequestMapping(value="ViewFeedbackReport")
	public ModelAndView ViewAllFeedbackReport(){
		ModelAndView view=new ModelAndView();
		ArrayList<FeedbackBean> list=service.viewAllFeedbackReport();
		/*for (FeedbackBean feedbackBean : list) {
			System.out.println(feedbackBean.getComments());
		}*/
		if(list.isEmpty()){
			String errorMessage="No Feedback are available";
			view = new ModelAndView("ViewFeedbackReport");
			view.addObject("errorMessage", errorMessage);
		}
		else{
			view = new ModelAndView("ViewFeedbackReport");
			view.addObject("feedbackList", list);
		}
		return view;
	}

	/*****************Cordinator Operations*****************/
	@RequestMapping(value="TrainingProgramMaintenance")
	public ModelAndView trainingProgramMaintenance(){
		ModelAndView view = new ModelAndView("TrainingProgramMaintenance");
		return view;
	}

	@RequestMapping(value="AddTrainingProgram")
	public ModelAndView addTrainingProgram(){
		ModelAndView view=new ModelAndView();
		ArrayList<Integer> list=service.retrieveCourseCode();
		view = new ModelAndView("AddTrainingProgram","beankey",new TrainingProgramBean());
		view.addObject("courseCode", list);
		return view;
	}
	
	@RequestMapping(value="AddTrainingProgramSuccess")
	public ModelAndView addTrainingProgramSuccess(Model model,@ModelAttribute("beankey") @Valid TrainingProgramBean programBean){
		ModelAndView view=new ModelAndView();
		boolean value=service.addTrainingProgram(programBean);
		if(value==true){
			view = new ModelAndView("AddTrainingProgramSuccess");
			model.addAttribute("trainingCode",programBean.getTrainingCode());
		}
		return view;
	}

	/*****************User Role******************/
	@RequestMapping(value="UserSuccess")
	public ModelAndView userSuccess(@ModelAttribute("beankey") @Valid FeedbackBean feedbackBean,BindingResult result){
		ModelAndView view=new ModelAndView();
		boolean value=service.addFeedback(feedbackBean);
		if(value==true){
			String msg="Your feedback has been submitted successfully";
			view=new ModelAndView("UserSuccess");
			view.addObject("message", msg);
		}
		return view;
	}
}