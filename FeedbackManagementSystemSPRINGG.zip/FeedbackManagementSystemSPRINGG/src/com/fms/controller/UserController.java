package com.fms.controller;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.fms.bean.CourseMasterBean;
import com.fms.bean.FacultySkillBean;
import com.fms.bean.UserBean;
import com.fms.service.IUserService;

@Controller
public class UserController {
	@Autowired
	IUserService service;

	@RequestMapping("index")
	public ModelAndView homepage(){
		UserBean bean=new UserBean();
		ModelAndView view = new ModelAndView("homepage","beankey",bean);
		return view;
	}

	@RequestMapping(value="validateUserDetails",method=RequestMethod.POST)
	public ModelAndView retrieveDetails(Model model,@ModelAttribute("beankey") @Valid UserBean userBean,BindingResult result){

		boolean value=false;
		ModelAndView view=new ModelAndView();
		value=service.retrieveDetails(userBean.getEmpId(), userBean.getPassword());
		/*if(result.hasErrors()){
			view = new ModelAndView("homepage");
		}*/
		//else{
			if(value==false){
				String errorMessage="Invalid Credentials";
				view = new ModelAndView("homepage");
				view.addObject("errorMessage", errorMessage);
			}
			else{
				view = new ModelAndView("adminHome");
			}
		//}
		return view;
	}

	/******************Admin Operations*********************/

	@RequestMapping(value="ViewFeedbackReport")
	public ModelAndView viewViewFeedbackReport(){
		ModelAndView view = new ModelAndView("ViewFeedbackReport");
		return view;
	}

	//FacultyMaintenance
	@RequestMapping(value="FacultySkillMaintenance")
	public ModelAndView viewFacultySkillMaintenance(){
		ModelAndView view = new ModelAndView("FacultySkillMaintenance");
		return view;
	}

	@RequestMapping(value="viewFaculty")
	public ModelAndView viewFaculty(){
		ModelAndView view=new ModelAndView();
		ArrayList<FacultySkillBean> list=service.retrieveFacultyDetails();
		if(list.isEmpty()){
			String errorMessage="No faculty details are available";
			view = new ModelAndView("viewFaculty");
			view.addObject("errorMessage", errorMessage);
		}
		else{
			view = new ModelAndView("viewFaculty");
			view.addObject("facultyList", list);
		}
		return view;
	}

	@RequestMapping(value="addFaculty")
	public ModelAndView addFaculty(){
		ModelAndView view=new ModelAndView("addFaculty");
		return view;
	}

	//Course Maintainence
	@RequestMapping(value="CourseMaintenance")
	public ModelAndView viewCourseMaintenance(){
		ModelAndView view = new ModelAndView("CourseMaintenance");
		return view;
	}

	@RequestMapping(value="ViewCourse")
	public ModelAndView viewCourseDetails(){
		ModelAndView view=new ModelAndView();
		ArrayList<CourseMasterBean> list=service.retrieveCourseDetails();
		if(list.isEmpty()){
			String errorMessage="No courses are available";
			view = new ModelAndView("ViewCourse");
			view.addObject("errorMessage", errorMessage);
		}
		else{
			view = new ModelAndView("ViewCourse");
			view.addObject("courseList", list);
		}
		return view;
	}

	@RequestMapping(value="AddCourse",method=RequestMethod.GET)
	public ModelAndView addCourse(){
		ModelAndView view=new ModelAndView("AddCourse","bean",new CourseMasterBean());
		return view;
	}
	
	@RequestMapping(value="AddCourseSuccess")
	public ModelAndView courseAddSuccess(Model model,@ModelAttribute("bean") @Valid CourseMasterBean courseMasterBean,BindingResult result){
		ModelAndView view=new ModelAndView();
		boolean value=service.addCourseDetails(courseMasterBean);
		if(value==true){
			view = new ModelAndView("AddCourseSuccess");
			model.addAttribute("id",courseMasterBean.getCourseId());
		}
		else{
			String errorMessage="Course cannot be added";
			view = new ModelAndView("AddCourse");
			view.addObject("errorMessage", errorMessage);
		}
		return view;
	}
	
	@RequestMapping(value="DeleteCourse",method=RequestMethod.GET)
	public ModelAndView deleteCourse(){
		ModelAndView view=new ModelAndView("DeleteCourse","bean",new CourseMasterBean());
		return view;
	}
	
	
	@RequestMapping(value="ValidateCourse")
	public ModelAndView coursedDeleteSuccess(Model model,@ModelAttribute("bean") @Valid CourseMasterBean courseMasterBean,BindingResult result){
		ModelAndView view=new ModelAndView();
		boolean value=service.validateCourse(courseMasterBean.getCourseId());
		if(value==true){
			view = new ModelAndView("DeleteCourseSuccess");
			model.addAttribute("id",courseMasterBean.getCourseId());
		}
		else{
			String errorMessage="Course with this ID is not available and hence cannot be deleted";
			view = new ModelAndView("DeleteCourse");
			view.addObject("errorMessage", errorMessage);
		}
		return view;
	}
	
	/*****************User Role******************/
	
}