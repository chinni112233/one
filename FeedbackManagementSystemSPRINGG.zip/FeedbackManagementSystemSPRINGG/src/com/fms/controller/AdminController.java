/*package com.fms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.fms.service.IAdminService;

@Controller
public class AdminController {
	@Autowired
	IAdminService service1;
	
	@RequestMapping(value="FacultySkillMaintenance")
	public ModelAndView viewFacultySkillMaintenance(){
		ModelAndView view = new ModelAndView("FacultySkillMaintenance");
		return view;
	}
	
	@RequestMapping(value="CourseMaintenance")
	public ModelAndView viewCourseMaintenance(){
		ModelAndView view = new ModelAndView("CourseMaintenance");
		return view;
	}
	
	@RequestMapping(value="ViewFeedbackReport")
	public ModelAndView viewViewFeedbackReport(){
		ModelAndView view = new ModelAndView("ViewFeedbackReport");
		return view;
	}
}
*/