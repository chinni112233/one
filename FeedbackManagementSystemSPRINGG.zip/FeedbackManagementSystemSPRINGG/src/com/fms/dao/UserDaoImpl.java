package com.fms.dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.fms.bean.CourseMasterBean;
import com.fms.bean.FacultySkillBean;
import com.fms.bean.FeedbackBean;
import com.fms.bean.TrainingParticiEnrollBean;
import com.fms.bean.TrainingProgramBean;
import com.fms.bean.UserBean;


@Repository("dao")
@Transactional
public class UserDaoImpl implements IUserDao{
	boolean result=false;

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public boolean retrieveDetails(int employeeID, String employeePass) {
		Query query=entityManager.createNamedQuery("retrieveUserDetails");
		query.setParameter("empId", employeeID);
		query.setParameter("pass", employeePass);
		@SuppressWarnings("unchecked")
		ArrayList<UserBean> list=(ArrayList<UserBean>) query.getResultList();
		if(list.isEmpty()){
			result=false;
		}
		else{
			result=true;
		}
		return result;
	}
	
	@Override
	public ArrayList<UserBean> retrieveDetail(int employeeID,String employeePass) {
		Query query=entityManager.createNamedQuery("retrieveDetails");
		query.setParameter("empId", employeeID);
		query.setParameter("pass", employeePass);
		@SuppressWarnings("unchecked")
		ArrayList<UserBean> list=(ArrayList<UserBean>) query.getResultList();
		return list;
	}
	
	@Override
	public ArrayList<FacultySkillBean> retrieveFacultyDetails() {
		Query query=entityManager.createNamedQuery("retrieveFacultyDetails");
		@SuppressWarnings("unchecked")
		ArrayList<FacultySkillBean> list=(ArrayList<FacultySkillBean>) query.getResultList();
		return list;
	}

	@Override
	public ArrayList<CourseMasterBean> retrieveCourseDetails() {
		Query query=entityManager.createNamedQuery("retrieveCourseDetails");
		@SuppressWarnings("unchecked")
		ArrayList<CourseMasterBean> list=(ArrayList<CourseMasterBean>) query.getResultList();
		return list;
	}

	@Override
	public boolean addCourseDetails(CourseMasterBean courseMasterBean) {
		entityManager.persist(courseMasterBean);
		entityManager.flush();
		return true;
	}

	@Override
	public boolean validateCourse(int courseId) {
		CourseMasterBean bean=entityManager.find(CourseMasterBean.class,courseId);
		if(bean!=null){
			entityManager.remove(bean);
			result=true;
		}
		else{
			result=false;
		}
		return result;
	}

	@Override
	public ArrayList<CourseMasterBean> retrieveCourses() {
		Query query=entityManager.createNamedQuery("retrieveCourses");
		@SuppressWarnings("unchecked")
		ArrayList<CourseMasterBean> list=(ArrayList<CourseMasterBean>) query.getResultList();
		return list;
	}

	@Override
	public boolean addFeedback(FeedbackBean feedbackBean) {
		entityManager.persist(feedbackBean);
		entityManager.flush();
		return true;
	}

	@Override
	public ArrayList<TrainingParticiEnrollBean> retrieveFeedbackDetails(Integer empId) {
		Query query=entityManager.createNamedQuery("retrieveTrainingCode");
		query.setParameter("userId",empId);
		@SuppressWarnings("unchecked")
		ArrayList<TrainingParticiEnrollBean> list=(ArrayList<TrainingParticiEnrollBean>) query.getResultList();
		return list;
	}

	@Override
	public ArrayList<FeedbackBean> viewAllFeedbackReport() {
		Query query=entityManager.createNamedQuery("viewAllFeedbackReport");
		@SuppressWarnings("unchecked")
		ArrayList<FeedbackBean> list=(ArrayList<FeedbackBean>) query.getResultList();
		return list;
	}

	@Override
	public ArrayList<Integer> retrieveCourseCode() {
		Query query=entityManager.createQuery("select c.courseId from CourseMasterBean c");
		@SuppressWarnings("unchecked")
		ArrayList<Integer> list=(ArrayList<Integer>) query.getResultList();
		System.out.println(list);
		return list;
	}

	@Override
	public boolean addTrainingProgram(TrainingProgramBean programBean) {
		String startDate=programBean.getDate0();
		String endDate=programBean.getDate1();
		SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
		java.util.Date parsed1=null;
		java.util.Date parsed2=null;
		try {
			parsed1 =format.parse(startDate);
			parsed2 =format.parse(endDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		java.sql.Date sqlStartDate = new java.sql.Date(parsed1.getTime());
		java.sql.Date sqlEndDate = new java.sql.Date(parsed2.getTime());
		programBean.setStartDate(sqlStartDate);
		programBean.setStartDate(sqlEndDate);
		entityManager.persist(programBean);
		entityManager.flush();
		return true;
	}

}
