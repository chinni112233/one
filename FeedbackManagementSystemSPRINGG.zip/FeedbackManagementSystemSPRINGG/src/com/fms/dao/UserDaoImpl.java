package com.fms.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.fms.bean.CourseMasterBean;
import com.fms.bean.FacultySkillBean;
import com.fms.bean.UserBean;


@Repository("dao")
@Transactional
public class UserDaoImpl implements IUserDao{
	boolean result=false;

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public boolean retrieveDetails(int employeeID, String employeePass) {
		Query query=entityManager.createNamedQuery("retrieveUserDetails");
		query.setParameter("empId", employeeID);
		query.setParameter("pass", employeePass);
		@SuppressWarnings("unchecked")
		ArrayList<UserBean> list=(ArrayList<UserBean>) query.getResultList();
		if(list.isEmpty()){
			result=false;
		}
		else{
			result=true;
		}
		return result;
	}
	
	@Override
	public ArrayList<FacultySkillBean> retrieveFacultyDetails() {
		Query query=entityManager.createNamedQuery("retrieveFacultyDetails");
		@SuppressWarnings("unchecked")
		ArrayList<FacultySkillBean> list=(ArrayList<FacultySkillBean>) query.getResultList();
		return list;
	}

	@Override
	public ArrayList<CourseMasterBean> retrieveCourseDetails() {
		Query query=entityManager.createNamedQuery("retrieveCourseDetails");
		@SuppressWarnings("unchecked")
		ArrayList<CourseMasterBean> list=(ArrayList<CourseMasterBean>) query.getResultList();
		return list;
	}

	@Override
	public boolean addCourseDetails(CourseMasterBean courseMasterBean) {
		entityManager.persist(courseMasterBean);
		entityManager.flush();
		return true;
	}

	@Override
	public boolean validateCourse(int courseId) {
		CourseMasterBean bean=entityManager.find(CourseMasterBean.class,courseId);
		if(bean!=null){
			entityManager.remove(bean);
			result=true;
		}
		else{
			result=false;
		}
		return result;
	}

	@Override
	public ArrayList<CourseMasterBean> retrieveCourses() {
		Query query=entityManager.createNamedQuery("retrieveCourses");
		@SuppressWarnings("unchecked")
		ArrayList<CourseMasterBean> list=(ArrayList<CourseMasterBean>) query.getResultList();
		return list;
	}

}
