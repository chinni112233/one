package com.fms.service;

import java.util.ArrayList;

import com.fms.bean.CourseMasterBean;
import com.fms.bean.FacultySkillBean;
import com.fms.bean.FeedbackBean;
import com.fms.bean.TrainingParticiEnrollBean;
import com.fms.bean.TrainingProgramBean;
import com.fms.bean.UserBean;

public interface IUserService {
	public boolean retrieveDetails(int employeeID,String employeePass);
	public ArrayList<UserBean> retrieveDetail(int employeeID,String employeePass);
	public ArrayList<FacultySkillBean> retrieveFacultyDetails();
	public ArrayList<CourseMasterBean> retrieveCourseDetails();
	public boolean addCourseDetails(CourseMasterBean courseMasterBean);
	public boolean validateCourse(int courseId);
	public ArrayList<CourseMasterBean> retrieveCourses();
	public boolean addFeedback(FeedbackBean feedbackBean);
	public ArrayList<TrainingParticiEnrollBean> retrieveFeedbackDetails(Integer empId);
	public ArrayList<FeedbackBean> viewAllFeedbackReport();
	public ArrayList<Integer> retrieveCourseCode();
	public boolean addTrainingProgram(TrainingProgramBean programBean);
}
