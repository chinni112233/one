package com.fms.service;

import java.util.ArrayList;

import com.fms.bean.CourseMasterBean;
import com.fms.bean.FacultySkillBean;
import com.fms.bean.UserBean;

public interface IUserService {
	public boolean retrieveDetails(int employeeID,String employeePass);
	public ArrayList<FacultySkillBean> retrieveFacultyDetails();
	public ArrayList<CourseMasterBean> retrieveCourseDetails();
	public boolean addCourseDetails(CourseMasterBean courseMasterBean);
	public boolean validateCourse(int courseId);
	public ArrayList<CourseMasterBean> retrieveCourses();
}
