package com.fms.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fms.bean.CourseMasterBean;
import com.fms.bean.FacultySkillBean;
import com.fms.bean.UserBean;
import com.fms.dao.IUserDao;
import com.fms.dao.UserDaoImpl;

@Service("service")
public class UserServiceImpl implements IUserService{
	
	@Autowired
	IUserDao dao;
	
	@Override
	public boolean retrieveDetails(int employeeID,String employeePass) {
		return dao.retrieveDetails(employeeID,employeePass);
	}

	@Override
	public ArrayList<FacultySkillBean> retrieveFacultyDetails() {
		return dao.retrieveFacultyDetails();
	}

	@Override
	public ArrayList<CourseMasterBean> retrieveCourseDetails() {
		return dao.retrieveCourseDetails();
	}

	@Override
	public boolean addCourseDetails(CourseMasterBean courseMasterBean) {
		return dao.addCourseDetails(courseMasterBean);
	}

	@Override
	public boolean validateCourse(int courseId) {
		return dao.validateCourse(courseId);
	}

	@Override
	public ArrayList<CourseMasterBean> retrieveCourses() {
		return dao.retrieveCourses();
	}

}
