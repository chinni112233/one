package com.fms.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fms.bean.CourseMasterBean;
import com.fms.bean.FacultySkillBean;
import com.fms.bean.FeedbackBean;
import com.fms.bean.TrainingParticiEnrollBean;
import com.fms.bean.TrainingProgramBean;
import com.fms.bean.UserBean;
import com.fms.dao.IUserDao;
import com.fms.dao.UserDaoImpl;

@Service("service")
public class UserServiceImpl implements IUserService{
	
	@Autowired
	IUserDao dao;
	
	@Override
	public boolean retrieveDetails(int employeeID,String employeePass) {
		return dao.retrieveDetails(employeeID,employeePass);
	}

	@Override
	public ArrayList<FacultySkillBean> retrieveFacultyDetails() {
		return dao.retrieveFacultyDetails();
	}

	@Override
	public ArrayList<CourseMasterBean> retrieveCourseDetails() {
		return dao.retrieveCourseDetails();
	}

	@Override
	public boolean addCourseDetails(CourseMasterBean courseMasterBean) {
		return dao.addCourseDetails(courseMasterBean);
	}

	@Override
	public boolean validateCourse(int courseId) {
		return dao.validateCourse(courseId);
	}

	@Override
	public ArrayList<CourseMasterBean> retrieveCourses() {
		return dao.retrieveCourses();
	}

	@Override
	public ArrayList<UserBean> retrieveDetail(int employeeID,
			String employeePass) {
		return dao.retrieveDetail(employeeID, employeePass);
	}

	@Override
	public boolean addFeedback(FeedbackBean feedbackBean) {
		return dao.addFeedback(feedbackBean);
	}

	@Override
	public ArrayList<TrainingParticiEnrollBean> retrieveFeedbackDetails(Integer empId) {
		return dao.retrieveFeedbackDetails(empId);
	}

	@Override
	public ArrayList<FeedbackBean> viewAllFeedbackReport() {
		return dao.viewAllFeedbackReport();
	}

	@Override
	public ArrayList<Integer> retrieveCourseCode() {
		return dao.retrieveCourseCode();
	}

	@Override
	public boolean addTrainingProgram(TrainingProgramBean programBean) {
		return dao.addTrainingProgram(programBean);
	}

}
