package com.fms.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="employee_master")

@NamedQueries({@NamedQuery(name="retrieveUserDetails",query="select u from UserBean u where u.empId=:empId AND u.password=:pass")})


public class UserBean {
	
	@Id
	@NotNull(message="This field cannot be empty")
	@Column(name="employee_id")
	private int empId;
	
	@NotEmpty(message="This field cannot be empty")
	@Column(name="password")
	private String password;
	
	@NotEmpty(message="This field cannot be empty")
	@Column(name="role")
	private String role;
	
	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public int getEmpId() {
		return empId;
	}
	
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}
