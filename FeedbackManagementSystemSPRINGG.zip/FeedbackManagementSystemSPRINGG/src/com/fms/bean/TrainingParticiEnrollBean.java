package com.fms.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="training_partici_enroll")

@NamedQueries({@NamedQuery(name="retrieveTrainingCode",query="select f.trainingCode from TrainingParticiEnrollBean f where f.participantId=:userId")})

public class TrainingParticiEnrollBean {
	@Id
	@Column(name="training_code")
	private Integer trainingCode;
	
	@Column(name="participant_id")
	private Integer participantId;

	public Integer getTrainingCode() {
		return trainingCode;
	}

	public void setTrainingCode(Integer trainingCode) {
		this.trainingCode = trainingCode;
	}

	public Integer getParticipantId() {
		return participantId;
	}

	public void setParticipantId(Integer participantId) {
		this.participantId = participantId;
	}
	
	
}
