package com.fms.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="faculty_skill")

@NamedQueries({@NamedQuery(name="retrieveFacultyDetails",query="select f from FacultySkillBean f")})

public class FacultySkillBean {
	
	@Id
	@Column(name="faculty_id")
	private int facultyId;
	
	@NotNull(message="This field cannot be empty")
	@Column(name="skill_set")
	private String facultySkillSet;

	public int getFacultyId() {
		return facultyId;
	}

	public void setFacultyId(int facultyId) {
		this.facultyId = facultyId;
	}

	public String getFacultySkillSet() {
		return facultySkillSet;
	}

	public void setFacultySkillSet(String facultySkillSet) {
		this.facultySkillSet = facultySkillSet;
	}

	@Override
	public String toString() {
		return "AdminBean [facultyId=" + facultyId + ", facultySkillSet="
				+ facultySkillSet + "]";
	}
	
	
}
