package com.fms.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="feedback_master")

@NamedQueries({@NamedQuery(name="viewAllFeedbackReport",query="select f from FeedbackBean f")})


public class FeedbackBean {
	@Id
	@Column(name="training_code")
	private Integer trainingCode;
	
	@Column(name="participant_id")
	private Integer participantId;
	
	@Column(name="FB_Prs_comm")
	private Integer FBPrscomm;
	
	@Column(name="FB_Clrfy_dbts")
	private Integer FBClrfydbts;
	
	@Column(name="FB_TM")
	private Integer FBTM;
	
	@Column(name="FB_Hnd_out")
	private Integer FBHndout;
	
	@Column(name="FB_Hw_Sw_Ntwrk")
	private Integer FBHwSwNtwrk;
	
	private String comments;
	
	private String suggestions;

	public Integer getTrainingCode() {
		return trainingCode;
	}

	public void setTrainingCode(Integer trainingCode) {
		this.trainingCode = trainingCode;
	}

	public Integer getParticipantId() {
		return participantId;
	}

	public void setParticipantId(Integer participantId) {
		this.participantId = participantId;
	}

	public Integer getFBPrscomm() {
		return FBPrscomm;
	}

	public void setFBPrscomm(Integer fBPrscomm) {
		FBPrscomm = fBPrscomm;
	}

	public Integer getFBClrfydbts() {
		return FBClrfydbts;
	}

	public void setFBClrfydbts(Integer fBClrfydbts) {
		FBClrfydbts = fBClrfydbts;
	}

	public Integer getFBTM() {
		return FBTM;
	}

	public void setFBTM(Integer fBTM) {
		FBTM = fBTM;
	}

	public Integer getFBHndout() {
		return FBHndout;
	}

	public void setFBHndout(Integer fBHndout) {
		FBHndout = fBHndout;
	}

	public Integer getFBHwSwNtwrk() {
		return FBHwSwNtwrk;
	}

	public void setFBHwSwNtwrk(Integer fBHwSwNtwrk) {
		FBHwSwNtwrk = fBHwSwNtwrk;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getSuggestions() {
		return suggestions;
	}

	public void setSuggestions(String suggestions) {
		this.suggestions = suggestions;
	}


}
