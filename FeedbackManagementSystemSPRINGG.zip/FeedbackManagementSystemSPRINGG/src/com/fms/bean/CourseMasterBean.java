package com.fms.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="course_master")

@NamedQueries({@NamedQuery(name="retrieveCourseDetails",query="select c from CourseMasterBean c"),
		@NamedQuery(name="retrieveCourses",query="select c.courseId from CourseMasterBean c")})
public class CourseMasterBean {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO,generator = "author_generator")
	@SequenceGenerator(name="author_generator", sequenceName = "course_id_sequence")
	@Column(name="course_id")
	private int courseId;
	
	@Column(name="course_name")
	private String courseName;
	
	@Column(name="no_of_days")
	private int noOfDays;
	
	
	public int getCourseId() {
		return courseId;
	}
	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public int getNoOfDays() {
		return noOfDays;
	}
	public void setNoOfDays(int noOfDays) {
		this.noOfDays = noOfDays;
	}
	
	@Override
	public String toString() {
		return "CourseMasterBean [courseId=" + courseId + ", courseName="
				+ courseName + ", noOfDays=" + noOfDays + "]";
	}
	
	
}
