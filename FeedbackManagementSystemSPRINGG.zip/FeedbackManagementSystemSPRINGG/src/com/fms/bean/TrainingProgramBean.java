package com.fms.bean;

import java.sql.Date;
import java.util.ArrayList;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="training_program")

//@NamedQueries({@NamedQuery(name="retrieveCourseCode",query="select t.courseCode from TrainingProgramBean t,CourseMasterBean c where t.courseCode=c.courseId")})

public class TrainingProgramBean {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO,generator = "author_generator")
	@SequenceGenerator(name="author_generator", sequenceName = "training_code_sequence")
	@Column(name="training_code")
	private int trainingCode;
	
	@Column(name="course_code")
	private Integer courseCode;
	
	@Column(name="faculty_code")
	private Integer facultyCode;
	
	@Transient
	private String date0;
	
	@Column(name="start_date")
	private Date startDate;
	
	@Transient
	private String date1;
	
	@Column(name="end_date")
	private Date endDate;

	public int getTrainingCode() {
		return trainingCode;
	}

	public void setTrainingCode(int trainingCode) {
		this.trainingCode = trainingCode;
	}

	public String getDate0() {
		return date0;
	}

	public void setDate0(String date0) {
		this.date0 = date0;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public String getDate1() {
		return date1;
	}

	public void setDate1(String date1) {
		this.date1 = date1;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Integer getCourseCode() {
		return courseCode;
	}

	public void setCourseCode(Integer courseCode) {
		this.courseCode = courseCode;
	}

	public Integer getFacultyCode() {
		return facultyCode;
	}

	public void setFacultyCode(Integer facultyCode) {
		this.facultyCode = facultyCode;
	}
	
	
}
